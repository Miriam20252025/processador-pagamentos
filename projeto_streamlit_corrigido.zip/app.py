
import streamlit as st
import pandas as pd
import fitz  # PyMuPDF
import re
import io
import os

st.set_page_config(page_title="Processador de Pagamentos", layout="centered")
st.title("📄 Processar Relatório de Líquidos")

# Upload do PDF
uploaded_pdf = st.file_uploader("Faça o upload do PDF da contabilidade (Relatorio Liquidos.pdf)", type=["pdf"])

# Código de pagamento
codigo_pagamento = st.selectbox("Selecione a finalidade de pagamento (código)", [
    "1 - Salário",
    "2 - Férias",
    "3 - Vale transporte",
    "4 - Vale alimentação",
    "5 - Comissão",
    "6 - Décimo terceiro",
    "7 - Bolsa estágio",
    "8 - Bônus",
    "9 - Adiantamento salarial",
    "10 - Rescisão contratual",
    "11 - Bolsa auxílio",
    "12 - Pensão alimentícia",
    "13 - Conta corrente",
    "14 - Remuneração"
])

# Processamento ao clicar no botão
if st.button("📊 Processar Planilha"):
    if uploaded_pdf is None:
        st.error("❌ Por favor, envie o PDF antes de processar.")
    else:
        try:
            codigo = int(codigo_pagamento.split(" - ")[0])

            # Extrair dados do PDF
            doc = fitz.open(stream=uploaded_pdf.read(), filetype="pdf")
            dados_extraidos = []
            for page in doc:
                texto = page.get_text()
                linhas = texto.split("\n")
                for linha in linhas:
                    cpf_match = re.search(r"\d{3}\.\d{3}\.\d{3}-\d{2}", linha)
                    valor_match = re.search(r"([\d\.]+,\d{2})", linha)
                    if cpf_match and valor_match:
                        cpf = cpf_match.group(0)
                        valor = valor_match.group(1).replace(".", "").replace(",", ".")
                        dados_extraidos.append({"CPF": cpf, "Valor Líquido": float(valor)})

            df_pdf = pd.DataFrame(dados_extraidos)

            # Verificar se o arquivo da base está presente
            if os.path.exists("colaboradores.xlsx"):
                df_base = pd.read_excel("colaboradores.xlsx")
            elif os.path.exists("colaboradores.xls"):
                df_base = pd.read_excel("colaboradores.xls", engine="xlrd")
            else:
                st.error("❌ Nenhum arquivo 'colaboradores.xlsx' ou 'colaboradores.xls' encontrado no diretório.")
                st.stop()

            # Merge e adicionar coluna de código
            df_final = pd.merge(df_pdf, df_base, on="CPF", how="inner")
            df_final["Código Pagamento"] = codigo

            # Organizar colunas
            colunas_ordenadas = ["CPF", "Valor Líquido", "Código Pagamento"] + [
                col for col in df_final.columns if col not in ["CPF", "Valor Líquido", "Código Pagamento"]
            ]
            df_final = df_final[colunas_ordenadas]

            # Gerar CSV sem cabeçalho
            output = io.BytesIO()
            df_final.to_csv(output, sep=";", index=False, header=False)
            output.seek(0)

            st.success("✅ Planilha processada com sucesso!")
            st.download_button("📥 Baixar Planilha Consolidada", output, file_name="planilha_consolidada.csv", mime="text/csv")

        except Exception as e:
            st.error(f"⚠️ Erro durante o processamento: {e}")
